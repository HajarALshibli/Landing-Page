// Identify container, sections and empty unorder list.
const menu = document.getElementById("navbar__list");
const sections = [...document.querySelectorAll(".section")]
       

    const nav_menu_items = () => {
        let nav_menu_container = '';

        sections.forEach(section => {

            const sectionID = section.id;
            const sectionAtrribute = section.dataset.nav;
            nav_menu_container += `<li> <a class="menu_item_link" href="#${sectionID}">${sectionAtrribute}</a></li>`   
            })
        menu.innerHTML=nav_menu_container;

        }
        nav_menu_items();



//scroll sections to add and remove active class
navLinkEls = document.querySelectorAll('.menu_item_link');
sectionEls = document.querySelectorAll('.section');

let currentSection = 'section1';
window.addEventListener('scroll', () => {
  sectionEls.forEach(sectionEl =>{
    if (window.scrollY >= (sectionEl.offsetTop- sectionEl.clientHeight/2)) {
    currentSection = sectionEl.id;
  }
});

   navLinkEls.forEach(navLinkEl => {
    if (navLinkEl.href.includes(currentSection)){
      document.querySelector('.active')?.classList.remove('active');
      navLinkEl.classList.add('active');
    }
   }); 
});

    


//fun to see input section4
 function myFunction() {
  // Get the value of the input field with id="numb"
  let x = document.getElementById("numb").value;
  // If x is Not a Number or less than one or greater than 10
  let text;
  if (isNaN(x) || x < 1 || x > 10) {
    text = "Input not valid";
  } else {
    text = "Input OK";
  }
  document.getElementById("demo").innerHTML = text;
}