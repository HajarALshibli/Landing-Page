# Landing Page Project

## Project Description

A dynamic website. it is a web page that contains 4 sections with a menu.

## Instructions

The project contains an html file, a css file and a javascript file.
To open the HTML file `index.html`
To open the css file `css/styles.css`
To open the javascript file `js/app.js`

## Tools

1. sublime Text editor
2. Google Chrome
